/*
 * Nomes                        RA
 * Willian Rodrigues Chan       16.01095-7
 * Rodrigo Martins de Carvalho  16.03378-7
 */
package atividade1;


public class Carteira {
    private static double idCarteira;
    private String nomeCarteira;
    private String senhaAcesso;
    private Cartao cartaoDebito;
    private Cartao cartaoCredito;

    public Carteira(String nomeCarteira, String senhaAcesso) {
        Carteira.idCarteira ++;
        this.nomeCarteira = nomeCarteira;
        this.senhaAcesso = senhaAcesso;
        
    }
    public boolean alterarSenha(String senhaAntiga, String senhaNova){
        boolean saida = false;
        if(this.senhaAcesso == senhaAntiga){
            this.senhaAcesso = senhaNova;
            saida = true;
        }
        return saida;
    }

    
//    funçoes para cadastro de cartoes
    public boolean setCartaoDebito(Cartao cartaoDebito, String senha) {
        boolean saida = false;
        if(this.senhaAcesso == senha){
            this.cartaoDebito = cartaoDebito;
            saida = true;
        }
        return saida;
        
    }

    public boolean setCartaoCredito(Cartao cartaoCredito, String senha) {
        boolean saida = false;
        if(this.senhaAcesso == senha){
            this.cartaoCredito = cartaoCredito;
            saida = true;
        }
        return saida;
    }
//    metodos para excluir cartões da carteira
    public boolean excluirCartaoDebito(String senha){
        boolean saida = false;
        if(this.senhaAcesso == senha){
            this.cartaoDebito = null;
            saida = true;
        }
        return saida;
    }
    public boolean excluirCartaoCredito(String senha){
        boolean saida = false;
        if(this.senhaAcesso == senha){
            this.cartaoCredito = null;
            saida = true;
        }
        return saida;
    }
    public String informacoesCarteira(){
        return "idCarteira: " + Carteira.idCarteira + ", Nome Carteira: "+ this.nomeCarteira + ", Senha Acesso: " + this.senhaAcesso;
    }

    public static double getIdCarteira() {
        return idCarteira;
    }

    public String getNomeCarteira() {
        return nomeCarteira;
    }

    public String getSenhaAcesso() {
        return senhaAcesso;
    }

    public Cartao getCartaoDebito() {
        return cartaoDebito;
    }

    public Cartao getCartaoCredito() {
        return cartaoCredito;
    }
}
