/*
 * Nomes                        RA
 * Willian Rodrigues Chan       16.01095-7
 * Rodrigo Martins de Carvalho  16.03378-7
 */
package atividade1;

public class Cartao {
    
//  atributos
    private double taxaConversaoDolar;
    private static double idCartao;
    private String label;
    private String emissorCartao;
    private String tipo;
    private String dataEmissao;
    private String validade;
    private String ccv;
    private String numeroCartao;
    private String numeroConta;
//  construtor
    public Cartao(double taxaConversaoDolar, String label, String emissorCartao, String tipo, String dataEmissao, String validade, String ccv, String numeroCartao, String numeroConta) {
        this.taxaConversaoDolar = taxaConversaoDolar;
        Cartao.idCartao ++;
        this.label = label;
        this.emissorCartao = emissorCartao;
        this.tipo = tipo;
        this.dataEmissao = dataEmissao;
        this.validade = validade;
        this.ccv = ccv;
        this.numeroCartao = numeroCartao;
        this.numeroConta = numeroConta;
    }
//  getters
    public double getTaxaConversaoDolar() {
        return this.taxaConversaoDolar;
    }

    public double getIdCartao() {
        return Cartao.idCartao;
    }

    public String getLabel() {
        return this.label;
    }

    public String getEmissorCartao() {
        return this.emissorCartao;
    }

    public String getTipo() {
        return this.tipo;
    }

    public String getDataEmissao() {
        return this.dataEmissao;
    }

    public String getValidade() {
        return this.validade;
    }

    public String getCcv() {
        return this.ccv;
    }

    public String getNumeroCartao() {
        return this.numeroCartao;
    }

    public String getNumeroConta() {
        return this.numeroConta;
    }
    
    public String informacoesCartao(){
        return "Taxa Conversao Dolar: " + this.taxaConversaoDolar + ", Id Cartao: "+ Cartao.idCartao + ", Label Cartao: "+ this.label+ ", Emissor do Cartao: " +this.emissorCartao+ ", Tipo do cartao: "+ this.tipo+", Data de emissao: "+ this.dataEmissao+", Validade: " + this.validade +", CCV: " + this.ccv + ", numeroCartao: " +this.numeroCartao+", numero conta: " + this.numeroConta;
    }
}
