/*
 * Nomes                        RA
 * Willian Rodrigues Chan       16.01095-7
 * Rodrigo Martins de Carvalho  16.03378-7
 */
package atividade1;

/**
 *
 * @author 16.03378-7
 */
public class Usuario {
    private String nomeUsuario;
    private String emailUsuario;
    private String dataNascimentoUsuario;
    private String cPF;
    private Carteira carteira;

    public Usuario(String nomeUsuario, String emailUsuario, String dataNascimentoUsuario, String cPF, Carteira carteira) {
        this.nomeUsuario = nomeUsuario;
        this.emailUsuario = emailUsuario;
        this.dataNascimentoUsuario = dataNascimentoUsuario;
        this.cPF = cPF;
        this.carteira = carteira;
    }
    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public String getDataNascimentoUsuario() {
        return dataNascimentoUsuario;
    }

    public String getcPF() {
        return cPF;
    }

    public Carteira getCarteira() {
        return carteira;
    }
    //    metodo de transacao
    public void transacao(String senha, double valor){
        if(this.carteira.getSenhaAcesso() == senha){
            System.out.println("Transacao de "+ valor + " reais efetuada com sucesso");
        }
        else{
            System.out.println("FALHA NA TRANSACAO");
        }
    }
//    retorna uma string com as principais informacoes do usuario
    public String informacoesUsuario(){
        return "Nome Usuario: "+ this.nomeUsuario+", Email do Usuario: " + this.emailUsuario + ", Data de Nascimento: " + this.dataNascimentoUsuario + ", CPF: "+ this.cPF + ", Nome Carteira: " + this.carteira.getNomeCarteira();
    }
        
    
    
}
