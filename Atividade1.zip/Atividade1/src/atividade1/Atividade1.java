/*
 * Nomes                        RA
 * Willian Rodrigues Chan       16.01095-7
 * Rodrigo Martins de Carvalho  16.03378-7
 */
package atividade1;

public class Atividade1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Carteira carteira1;
        Carteira carteira2;
        Cartao debito1;
        Cartao debito2;
        Cartao credito2;
        Usuario usuario1;
        Usuario usuario2;
//        criacao de cartoes
        debito1 = new Cartao(4.00,"debito1","Visa","debito","04/05/2200","08/2200","000","51486214539875","1889-3");
        debito2 = new Cartao(4.00,"debito2","Visa","debito","04/05/2100","08/2100","100","52486214539875","1889-4");
        credito2 = new Cartao(4.00,"credito2","Mastercard","credito","06/05/2200","09/2200","080","5148621453985","18989-3");
//        criacao de carteira
        carteira1 = new Carteira("carteira1","glauber");
        carteira2 = new Carteira("carteira2","glauber2");
//        criacao de cartoes novos
        carteira1.setCartaoDebito(debito1, "glauber");
        carteira2.setCartaoCredito(credito2, "glauber2");
        carteira2.setCartaoDebito(debito2, "glauber2");
        
//        criacao dos usuarios
        usuario1 = new Usuario("Glauber","glauber@gmail.com","04/03/1998","000000000-68",carteira1); 
        usuario2 = new Usuario("Glauber Silva","glauber_silva@gmail.com","05/03/1998","000000000-69",carteira2);
       
//        operacao de pagamento
        usuario1.transacao("glauber",500);
        System.out.println(usuario1.informacoesUsuario());
        System.out.println(usuario1.getCarteira().informacoesCarteira());
        System.out.println(usuario1.getCarteira().getCartaoDebito().informacoesCartao());
        
        usuario2.transacao("glauber2", 500000);
        System.out.println(usuario2.informacoesUsuario() ); 
        System.out.println(usuario2.getCarteira().informacoesCarteira() );
        System.out.println(usuario2.getCarteira().getCartaoDebito().informacoesCartao());
        System.out.println(usuario2.getCarteira().getCartaoCredito().informacoesCartao() );
        
        
    }
    
    
}
